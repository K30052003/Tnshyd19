package com.si.csit;

public class IPL {
	 String batsman="Virat Kohli";
	 static String bowler="shami";
	 void display() {
		 System.out.println("Match");
	 }
	 static String display1() {
		 return"Cricket";
	 }
	 public static void main(String[] args) {
		IPL i1=new IPL();
		System.out.println("i1.batsman");
		i1.display();
		System.out.println("IPL.bowler");
		IPL.display1();		
	}
}
