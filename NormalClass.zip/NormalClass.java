package com.si.csit;

public class NormalClass{
	String batsman="Virat kohli";
	static String bowler="shami";
	void display()
	{
		System.out.println("Match");
	}
	static String display1()
	{
		return"cricket";
	}
	class Access{
		public static void main(String[] args) {
			NormalClass N1=new NormalClass();
			System.out.println("N1.batsman");
			N1.display();
			System.out.println("NormalClass.bowler");
			NormalClass.display1();
			
		}
	}
		
	

}
